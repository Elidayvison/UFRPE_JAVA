/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sidneynogueira
 */
public class TesteRestaurante {
    
    public static void main(String[] args) {

        Cardapio cardapio = new Cardapio();
        cardapio.adicionarItem("Caldinho", 10.49);
        cardapio.adicionarItem("Feijoada", 26.69);
        cardapio.imprimir();

        Pedido pedido1 = cardapio.fazerPedido("Caldinho", 2);
        pedido1.imprimir();
        

    }
    
}
