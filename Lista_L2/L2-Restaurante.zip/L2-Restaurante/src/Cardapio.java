
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author sidneynogueira
 */
public class Cardapio {
    
    private ArrayList<Item> itens;

    public Cardapio() {
        this.itens = new ArrayList<Item>();
    }
    
    public void adicionarItem(String nomeItem, double valor){
        Item item = new Item(nomeItem,valor);
        this.itens.add(item);
    }
    
    public Pedido fazerPedido(String nomeItem, int quantidade){
        Pedido pedido = null;
        for (Item item : itens) {
            if(item.getNome().equals(nomeItem)){
                pedido = new Pedido(item,quantidade);
                return pedido;
            }
        }
        return pedido;
    }
    
    void imprimir(){
        System.out.println("-----------------------------------------");
        System.out.println("ITENS DO CARDAPIO");
        System.out.println("-----------------------------------------");
        for (Item i : this.itens) {
            System.out.println(i);                    
        }
        System.out.println("-----------------------------------------");
    }
    
    
}
